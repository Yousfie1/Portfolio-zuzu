<!doctype html>
<html lang="en">

<head>
  <title>Title</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.0.2 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <?php
  if (isset($_POST['submit'])) {

    $name = $_POST['name'];
    $subject = $_POST['subject'];
    $mailFrom = $_POST['mail'];
    $message = $_POST['message'];

    $mailTo = "khalidalouat@hotmail.com";
    $headers = "From: " . $mailFrom;
    $txt = "Je hebt een mail ontvangen van: " . $name . ".\n\n" . $message;

    mail($mailTo, $subject, $txt);
    header("Location: contact.php?mailsent");
  }
  ?>
  <header>
    <!--- Navbar --->
    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <a class="navbar-brand text-white" href="#"><i class="fa fa-graduation-cap fa-lg mr-2"></i>Yousef Ahmed</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nvbCollapse" aria-controls="nvbCollapse">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="nvbCollapse">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item pl-1">
              <a class="nav-link" href="index.html"><i class="fa fa-home fa-fw mr-1"></i>Home</a>
            </li>
            <li class="nav-item active pl-1">
              <a class="nav-link" href="aboutme.html"><i class="fa fa-th-list fa-fw mr-1"></i>overmij</a>
            </li>
            <li class="nav-item pl-1">
              <a class="nav-link" href="projects.html"><i class="fa fa-info-circle fa-fw mr-1"></i>Projects</a>
            </li>
            <li class="nav-item pl-1">
              <a class="nav-link" href="contacts.php"><i class="fa fa-phone fa-fw fa-rotate-180 mr-1"></i>Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!--# Navbar #-->
  </header>
  <div class="contactForm">
    <form class="form_1" action="contactform.php" method="post">
      <h2>Stuur een mail</h2>
      <div class="form_2" class="inputBox">
        <input type="text" name="name">
        <span>Naam</span>
      </div>
      <div class="inputBox">
        <input type="text" name="mail">
        <span>E-mail</span>
      </div>
      <div class="inputBox">
        <input type="text" name="subject">
        <span>Onderwerp</span>
      </div>
      <div class="inputBox">
        <textarea class="Text1" name="message"></textarea>
        <span>Jouw bericht</span>

      </div>
      <button class="btn1" type="submit" name="submit">Verstuur bericht</button>
    </form>
  </div>
  <?php
  try {
    $db = new PDO("mysql:host=localhost;dbname=portfolio", "root", "");
    $query = $db->prepare("SELECT * FROM contactgegevens");
    $query->execute();
    $result = $query->fetchAll(PDO::FETCH_ASSOC);
    echo "<table>";
    foreach ($result as &$data) {
      echo "<td>" . $data["account"] . " ";
      echo "<td>" . $data["volgers"] . "<br>";
      echo "</tr>";
    }
    echo "</table>";
  } catch (PDOException $e) {
    die("Error!: " . $e->getMessage());
  }
  ?>
  <!--- Footer --->
  <footer>
    <div class="jumbotron jumbotron-fluid bg-secondary p-4 mt-5 mb-0">
      <div class="container">
        <div class="row">
          <div class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4 cizgi">
            <div class="card bg-secondary border-0">
              <div class="card-body text-light text-center">
                <h5 class="card-title text-white display-4" style="font-size:30px">Info</h5>
                <p class="d-inline lead">Yousef Ahmed © 2022<br>
                  <a href="#" class="text-light d-block lead">home</a>
                </p>

              </div>
            </div>
          </div>

          <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 cizgi">
            <div class="card bg-secondary border-0">
              <div class="card-body text-center">
                <h5 class="card-title text-white display-4" style="font-size:30px">Contact</h5>
                <a class="text-light d-block lead" style="margin-left: -20px" href="#"><i class="fa fa-phone mr-2"></i>+31611143065</a>
                <a class="text-light d-block lead" href="#"><i class="fa fa-envelope mr-2"></i>Yousfie2003@gmail.com</a>
              </div>
            </div>
          </div>

          <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4">
            <div class="card bg-secondary border-0">
              <div class="card-body text-center">
                <h5 class="card-title text-white display-4" style="font-size:30px">Social media</h5>

                <a class="text-light" href="#"><i class="fa fa-facebook-square fa-fw fa-2x"></i></a>

                <a class="text-light" href="#"><i class="fa fa-twitter-square fa-fw fa-2x"></i></a>

                <a class="text-light" href="#"><i class="fa fa-instagram fa-fw fa-2x"></i></a>

                <a class="text-light" href="#"><i class="fa fa-linkedin fa-fw fa-2x"></i></a>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!--# Footer #-->
  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
  <div class="row">
    <div class="col-md-6">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</body>

</html>